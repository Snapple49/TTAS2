#!/usr/bin/python
import unittest
import interface as i
import test_cases 
from test_cases import (TransactionsTestCase, GetVariableTestCase, 
						AccountTestCase, ArtRegTestCase, ArtIdTestCase)

if __name__ == '__main__':
	unittest.main()

